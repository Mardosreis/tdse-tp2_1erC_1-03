/*
 * Copyright (c) 2026 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 */

/********************** inclusions *******************************************/
/********************** inclusions *******************************************/
#include "main.h"
#include "logger.h"
#include "dwt.h"
#include "board.h"
#include "app.h"
#include "task_actuator_attribute.h"
#include "task_actuator_interface.h"

/********************** macros and definitions *******************************/
#define DEL_LED_MIN		0ul
#define DEL_LED_MED		250ul /* Velocidad de parpadeo (Blink) en ms */
#define DEL_LED_MAX		500ul

#define ACTUATOR_CFG_QTY	(sizeof(task_actuator_cfg_list)/sizeof(task_actuator_cfg_t))
#define ACTUATOR_DTA_QTY	ACTUATOR_CFG_QTY

/********************** internal data declaration ****************************/
/* * Configuración de hardware.
 * Ambos actuadores apuntan al LED_A para asegurar la compilación.
 * Si agregas un LED_B en CubeIDE, cambia los puertos/pines aquí.
 */
const task_actuator_cfg_t task_actuator_cfg_list[] = {
	{ID_LED_BARRIER_OPEN,  LED_A_PORT, LED_A_PIN, LED_A_ON, LED_A_OFF, DEL_LED_MED},
	{ID_LED_BARRIER_CLOSE, LED_A_PORT, LED_A_PIN, LED_A_ON, LED_A_OFF, DEL_LED_MED}
};

task_actuator_dta_t task_actuator_dta_list[ACTUATOR_DTA_QTY];

/********************** internal functions declaration ***********************/
void task_actuator_statechart(uint32_t index);

/********************** internal data definition *****************************/
const char *p_task_actuator 		= "Task Actuator (Actuator Statechart)";
const char *p_task_actuator_ 		= "Non-Blocking Code";
const char *p_task_actuator__ 		= "(Update by Time Code, period = 1mS)";

/********************** external functions definition ************************/
void task_actuator_init(void *parameters)
{
	uint32_t index;
	const task_actuator_cfg_t *p_task_actuator_cfg;
	task_actuator_dta_t *p_task_actuator_dta;

	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_actuator_init), HAL_GetTick());

	for (index = 0; ACTUATOR_DTA_QTY > index; index++)
	{
		p_task_actuator_cfg = &task_actuator_cfg_list[index];
		p_task_actuator_dta = &task_actuator_dta_list[index];

		/* Estado seguro inicial */
		p_task_actuator_dta->state = ST_LED_OFF;
		p_task_actuator_dta->event = EV_LED_OFF;
		p_task_actuator_dta->flag  = false;
		p_task_actuator_dta->tick  = DEL_LED_MIN;

		/* Apagar físicamente el hardware */
		HAL_GPIO_WritePin(p_task_actuator_cfg->gpio_port, p_task_actuator_cfg->pin, p_task_actuator_cfg->led_off);
	}
}

void task_actuator_update(void *parameters)
{
	uint32_t index;

	for (index = 0; ACTUATOR_DTA_QTY > index; index++)
	{
		task_actuator_statechart(index);
	}
}

void task_actuator_statechart(uint32_t index)
{
	const task_actuator_cfg_t *p_task_actuator_cfg;
	task_actuator_dta_t *p_task_actuator_dta;

	p_task_actuator_cfg = &task_actuator_cfg_list[index];
	p_task_actuator_dta = &task_actuator_dta_list[index];

	switch (p_task_actuator_dta->state)
	{
		case ST_LED_OFF:
			if (true == p_task_actuator_dta->flag)
			{
				p_task_actuator_dta->flag = false;

				if (EV_LED_ON == p_task_actuator_dta->event)
				{
					HAL_GPIO_WritePin(p_task_actuator_cfg->gpio_port, p_task_actuator_cfg->pin, p_task_actuator_cfg->led_on);
					p_task_actuator_dta->state = ST_LED_ON;
				}
				else if (EV_LED_BLINK == p_task_actuator_dta->event)
				{
					HAL_GPIO_WritePin(p_task_actuator_cfg->gpio_port, p_task_actuator_cfg->pin, p_task_actuator_cfg->led_on);
					p_task_actuator_dta->tick = p_task_actuator_cfg->tick_max;
					p_task_actuator_dta->state = ST_LED_BLINKING;
				}
			}
			break;

		case ST_LED_ON:
			if (true == p_task_actuator_dta->flag)
			{
				p_task_actuator_dta->flag = false;

				if (EV_LED_OFF == p_task_actuator_dta->event)
				{
					HAL_GPIO_WritePin(p_task_actuator_cfg->gpio_port, p_task_actuator_cfg->pin, p_task_actuator_cfg->led_off);
					p_task_actuator_dta->state = ST_LED_OFF;
				}
				else if (EV_LED_BLINK == p_task_actuator_dta->event)
				{
					HAL_GPIO_WritePin(p_task_actuator_cfg->gpio_port, p_task_actuator_cfg->pin, p_task_actuator_cfg->led_on);
					p_task_actuator_dta->tick = p_task_actuator_cfg->tick_max;
					p_task_actuator_dta->state = ST_LED_BLINKING;
				}
			}
			break;

		case ST_LED_BLINKING:
			/* 1. Prioridad a nuevos comandos entrantes (Apagar/Encender fijo) */
			if (true == p_task_actuator_dta->flag)
			{
				p_task_actuator_dta->flag = false;

				if (EV_LED_ON == p_task_actuator_dta->event)
				{
					HAL_GPIO_WritePin(p_task_actuator_cfg->gpio_port, p_task_actuator_cfg->pin, p_task_actuator_cfg->led_on);
					p_task_actuator_dta->state = ST_LED_ON;
				}
				else if (EV_LED_OFF == p_task_actuator_dta->event)
				{
					HAL_GPIO_WritePin(p_task_actuator_cfg->gpio_port, p_task_actuator_cfg->pin, p_task_actuator_cfg->led_off);
					p_task_actuator_dta->state = ST_LED_OFF;
				}
			}
			/* 2. Comportamiento natural: Alternar estado del pin cada X ms */
			else
			{
				if (p_task_actuator_dta->tick > 0)
				{
					p_task_actuator_dta->tick--;
				}
				else if (p_task_actuator_dta->tick == 0)
				{
					HAL_GPIO_TogglePin(p_task_actuator_cfg->gpio_port, p_task_actuator_cfg->pin);
					p_task_actuator_dta->tick = p_task_actuator_cfg->tick_max;
				}
			}
			break;

		default:
			p_task_actuator_dta->tick  = DEL_LED_MIN;
			p_task_actuator_dta->state = ST_LED_OFF;
			p_task_actuator_dta->event = EV_LED_OFF;
			p_task_actuator_dta->flag  = false;
			break;
	}
}
